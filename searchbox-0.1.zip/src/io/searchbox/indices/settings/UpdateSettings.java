package io.searchbox.indices.settings;

/**
 * @author Dogukan Sonmez
 */


public class UpdateSettings {
}
