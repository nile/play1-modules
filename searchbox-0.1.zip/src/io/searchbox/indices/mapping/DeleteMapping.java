package io.searchbox.indices.mapping;

/**
 * @author Dogukan Sonmez
 */


public class DeleteMapping {
}
